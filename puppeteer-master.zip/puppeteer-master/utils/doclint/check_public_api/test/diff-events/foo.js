class Foo {
}

