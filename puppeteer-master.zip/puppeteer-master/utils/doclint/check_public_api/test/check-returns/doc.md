### class: Foo

#### foo.asyncFunction()

#### foo.return42()

#### foo.returnNothing()
- returns: <[number]>

#### foo.www()
- returns <[string]>

[string]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Data_structures#String_type "String"
[number]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Data_structures#Number_type "Number"
