class Foo {
  constructor() {
    this.ddd = 10;
  }

  aaa() {}

  bbb() {}

  ccc() {}
}

