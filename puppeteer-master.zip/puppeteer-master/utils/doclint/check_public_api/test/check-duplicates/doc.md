### class: Bar

### class: Foo

#### foo.test()

#### foo.test()

#### foo.title(arg, arg)
- `arg` <[number]>
- `arg` <[number]>

### class: Bar

[number]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Data_structures#Number_type "Number"
