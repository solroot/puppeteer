const {FlakinessDashboard} = require('./FlakinessDashboard');

module.exports = {FlakinessDashboard};
