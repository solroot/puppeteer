window.__injected = 42;
window.__injectedError = new Error('hi');